import argparse
import json
import os
from datetime import datetime, timedelta, timezone
from collections import defaultdict
import yaml

try:
    import boto3
    from botocore.config import Config as BotoConfig
except Exception:
    boto3 = None

def load_yaml(path):
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def iso_to_dt(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)

def format_ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%SZ")

def fetch_events_aws(region: str, lookback_min: int):
    if boto3 is None:
        raise RuntimeError("boto3 not available. Install dependencies or use --mode offline.")
    client = boto3.client("cloudtrail", region_name=region, config=BotoConfig(retries={"max_attempts": 3}))
    end_time = datetime.now(timezone.utc)
    start_time = end_time - timedelta(minutes=lookback_min)

    events = []
    next_token = None
    while True:
        kwargs = {
            "StartTime": start_time,
            "EndTime": end_time,
            "MaxResults": 50,
        }
        if next_token:
            kwargs["NextToken"] = next_token
        resp = client.lookup_events(**kwargs)
        for e in resp.get("Events", []):
            try:
                evd = json.loads(e.get("CloudTrailEvent", "{}"))
                # Normalize a subset of fields used by rules
                normalized = {
                    "eventTime": evd.get("eventTime") or e.get("EventTime", end_time).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "eventName": evd.get("eventName") or e.get("EventName"),
                    "eventSource": evd.get("eventSource") or e.get("EventSource"),
                    "sourceIPAddress": evd.get("sourceIPAddress"),
                    "userIdentity": evd.get("userIdentity", {}),
                    "responseElements": evd.get("responseElements", {}),
                    "additionalEventData": evd.get("additionalEventData", {}),
                }
                events.append(normalized)
            except Exception:
                continue
        next_token = resp.get("NextToken")
        if not next_token:
            break
    return {"Records": events}

def load_events_offline(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def rule_failed_console_login_burst(records, threshold):
    findings = []
    failures_by_ip = defaultdict(int)
    for r in records:
        if r.get("eventName") == "ConsoleLogin" and r.get("eventSource") == "signin.amazonaws.com":
            if str(r.get("responseElements", {}).get("ConsoleLogin", "")).lower() == "failure":
                ip = r.get("sourceIPAddress") or "unknown"
                failures_by_ip[ip] += 1
    for ip, count in failures_by_ip.items():
        if count >= threshold:
            findings.append({
                "rule": "failed_console_login_burst",
                "severity": "medium",
                "message": f"{count} failed ConsoleLogin attempts from IP {ip} within lookback window",
                "ip": ip,
                "count": count
            })
    return findings

def rule_root_user_activity(records):
    findings = []
    for r in records:
        ui = r.get("userIdentity", {})
        if ui.get("type") == "Root":
            findings.append({
                "rule": "root_user_activity",
                "severity": "high",
                "message": f"Root user activity detected: {r.get('eventName')}",
                "eventName": r.get("eventName"),
                "time": r.get("eventTime")
            })
    return findings

def rule_iam_sensitive_changes(records, event_list):
    findings = []
    for r in records:
        if r.get("eventSource") == "iam.amazonaws.com" and r.get("eventName") in set(event_list):
            findings.append({
                "rule": "iam_sensitive_changes",
                "severity": "high",
                "message": f"IAM sensitive change: {r.get('eventName')}",
                "eventName": r.get("eventName"),
                "time": r.get("eventTime")
            })
    return findings

def rule_console_login_without_mfa(records):
    findings = []
    for r in records:
        if r.get("eventName") == "ConsoleLogin" and r.get("eventSource") == "signin.amazonaws.com":
            mfa = str(r.get("additionalEventData", {}).get("MFAUsed", "")).lower()
            result = str(r.get("responseElements", {}).get("ConsoleLogin", "")).lower()
            if result == "success" and mfa != "yes":
                findings.append({
                    "rule": "console_login_without_mfa",
                    "severity": "medium",
                    "message": "Successful console login without MFA",
                    "time": r.get("eventTime"),
                    "sourceIPAddress": r.get("sourceIPAddress"),
                })
    return findings

def run_rules(records, rules_cfg):
    findings = []
    if rules_cfg.get("failed_console_login_burst", {}).get("enabled", True):
        thr = rules_cfg["failed_console_login_burst"].get("threshold", 5)
        findings.extend(rule_failed_console_login_burst(records, thr))
    if rules_cfg.get("root_user_activity", {}).get("enabled", True):
        findings.extend(rule_root_user_activity(records))
    if rules_cfg.get("iam_sensitive_changes", {}).get("enabled", True):
        events = rules_cfg["iam_sensitive_changes"].get("events", [])
        findings.extend(rule_iam_sensitive_changes(records, events))
    if rules_cfg.get("console_login_without_mfa", {}).get("enabled", True):
        findings.extend(rule_console_login_without_mfa(records))
    return findings

def write_reports(findings, outdir):
    os.makedirs(outdir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    json_path = os.path.join(outdir, f"report_{ts}.json")
    md_path = os.path.join(outdir, f"report_{ts}.md")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(findings, f, indent=2)
    # Markdown summary
    lines = ["# Cloud Log Monitor Findings", "", f"Generated at: {datetime.now().isoformat(timespec='seconds')}", ""]
    if not findings:
        lines.append("✅ No findings in the selected window.")
    else:
        for i, fnd in enumerate(findings, 1):
            lines.append(f"## {i}. {fnd.get('rule')} — {fnd.get('severity').upper()}")
            lines.append(f"- **Message:** {fnd.get('message')}")
            for k, v in fnd.items():
                if k not in {"rule", "severity", "message"}:
                    lines.append(f"- **{k}:** {v}")
            lines.append("")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return json_path, md_path

def main():
    parser = argparse.ArgumentParser(description="Cloud Log Monitor — beginner-friendly CloudTrail analyzer")
    parser.add_argument("--mode", choices=["aws", "offline"], default="aws")
    parser.add_argument("--region", default="ap-south-1", help="AWS region (aws mode)")
    parser.add_argument("--lookback-min", type=int, default=60, help="Minutes to look back (aws mode)")
    parser.add_argument("--input", help="Path to offline JSON events (offline mode)")
    parser.add_argument("--rules", default="rules.yaml")
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--outdir", default="reports")
    args = parser.parse_args()

    rules_cfg = load_yaml(args.rules)
    _ = load_yaml(args.config)  # reserved for future

    if args.mode == "aws":
        events = fetch_events_aws(args.region, args.lookback_min)
    else:
        if not args.input:
            raise SystemExit("--input is required in offline mode")
        events = load_events_offline(args.input)

    records = events.get("Records", [])
    findings = run_rules(records, rules_cfg)
    json_path, md_path = write_reports(findings, args.outdir)
    print(f"Reports written:\n- {json_path}\n- {md_path}")

if __name__ == "__main__":
    main()
